CREATE TABLE `2014302580267_Goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price` float,
  `inventory` int(3),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;