CREATE TABLE `2014302580267_Comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(255),
  `gid` int(255),
  `star` int(255),
  `content` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;