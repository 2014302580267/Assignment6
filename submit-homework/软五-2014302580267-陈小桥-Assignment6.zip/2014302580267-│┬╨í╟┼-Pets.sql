CREATE TABLE `2014302580267_Pets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT '',
  `name` varchar(255) DEFAULT '',
  `age` varchar(255) DEFAULT '',
  `eat` varchar(255) DEFAULT '',
  `drink` varchar(255) DEFAULT '',
  `live` varchar(255) DEFAULT '',
  `hobby` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
