CREATE TABLE `2014302580267_Customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(20) DEFAULT '',
  `password` varchar(20) DEFAULT '',
  `iid` varchar(20) DEFAULT '',
  `account` float,
  `name` varchar(20) DEFAULT '',
  `sex` varchar(20) DEFAULT '',
  `phoneNumber` int(20),
  `email` varchar(40)DEFAULT '',
  `goodsList` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;