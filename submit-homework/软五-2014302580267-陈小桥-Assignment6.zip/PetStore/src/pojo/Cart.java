package pojo;

import java.util.List;

/**
 * ���ﳵ����
 * @author cxq
 *
 */
public class Cart {
	private int id;
	private List<Integer> list;
	
	public Cart(int id){
		this.id=id;
		list=null;
	}
	public int getId() {
		return id;
	}

	public List<Integer> getList() {
		return list;
	}

	public void setList(List<Integer> list) {
		this.list = list;
	}
	
}

