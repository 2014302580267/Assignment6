package pojo;

import java.util.Set;

/**
 * ��������
 * @author cxq
 *
 */
public class Pet {
	private int id;
	private String type;
	private String name;
	private String age;
	private String eat;
	private String drink;
	private String live;
	private Set<String> hobby;
	
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEat() {
		return eat;
	}
	public void setEat(String eat) {
		this.eat = eat;
	}
	public String getDrink() {
		return drink;
	}
	public void setDrink(String drink) {
		this.drink = drink;
	}
	public String getLive() {
		return live;
	}
	public void setLive(String live) {
		this.live = live;
	}
	public Set<String> getHobby() {
		return hobby;
	}
	public void setHobby(Set<String> hobby) {
		this.hobby = hobby;
	}

}

