package pojo;

import java.util.ArrayList;
import java.util.List;

/**
 * ����������
 * @author cxq
 *
 */
public class Customer {
	
	private int id;//id
	private String userName;
	private String password;
	private String iid;//����֤ID
	private float account;//�˺�money
	private String name;//����
	private String sex;//�Ա�
	private int phoneNumber;//�绰����
	private String Email;//����
	private List<Integer> goodsList=new ArrayList<Integer>();//���ﳵ
	
	public Customer(){
		
	}

	public Customer(int id){	
		setId(id);
		account=1000;	
	}
	
	public void setId(int id) {
		this.id = id;
	}
	public int getId() {
		return id;
	}
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	public String getIid() {
		return iid;
	}
	public void setIid(String iid) {
		this.iid = iid;
	}
	public float getAccount() {
		return account;
	}
	public void setAccount(float account) {
		this.account = account;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public int getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}

	public List<Integer> getGoodsList() {
		return goodsList;
	}

	public void setGoodsList(List<Integer> goodsList) {
		this.goodsList = goodsList;
	}
	
	//�����ﳵ�м�����Ʒ
	public void insertGood(int gid){
		boolean b=false;
		for(int i:goodsList){
			if(i==gid){
				b=true;break;
			}
		}
		if(goodsList.size()<3&&!b)
			goodsList.add(gid);
	}
	
	//ɾ�����ﳵ��ĳ����Ʒ
	public void deleteGood(int gid){
		if(goodsList.size()>0){
			for(int i=0;i<goodsList.size();i++){
				if(goodsList.get(i)==gid)
					goodsList.remove(i);
			}
		}
	}
}
