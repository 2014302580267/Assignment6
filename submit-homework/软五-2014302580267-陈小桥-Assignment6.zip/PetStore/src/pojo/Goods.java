package pojo;

import java.util.Set;

/**
 * ��Ʒ����
 * @author cxq
 *
 */
public class Goods {
	private int id;
	private Pet pet;
	private float price;
	private int inventory;
	private Set<Comment> comments;
	
	
	public void setId(int id){
		this.id=id;
	}
	public int getId() {
		return id;
	}
	public Pet getPet() {
		return pet;
	}
	public void setPet(Pet pet) {
		this.pet = pet;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getInventory() {
		return inventory;
	}
	public void setInventory(int inventory) {
		this.inventory = inventory;
	}
	public Set<Comment> getComments() {
		return comments;
	}
	public void setComments(Set<Comment> comments) {
		this.comments = comments;
	}
	
}
