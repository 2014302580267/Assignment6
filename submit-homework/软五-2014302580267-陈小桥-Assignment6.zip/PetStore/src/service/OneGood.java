package service;

import java.sql.SQLException;
import java.util.List;

import dao.CommentsData;
import dao.GoodsData;
import dao.PetsData;
import pojo.Comment;
import pojo.Pet;

/**
 * ��װͬID����Ʒ���Ժͳ�������
 * @author cxq
 *
 */
public class OneGood {
	private int id;
	private Pet pet;
	private float price;
	private int inventory;
	private List<Comment> comments;
	
	//�½�IDȷ������Ʒ
	public OneGood(int id) throws ClassNotFoundException, SQLException{
		PetsData petsData=new PetsData();
		GoodsData goodsData=new GoodsData();
		CommentsData commentsData=new CommentsData();
		this.id=id;
		this.pet=petsData.getPet(id);
		this.price=goodsData.getGoods(id).getPrice();
		this.inventory=goodsData.getGoods(id).getInventory();
		this.comments=commentsData.getCommentsByGid(id);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Pet getPet() {
		return pet;
	}

	public void setPet(Pet pet) {
		this.pet = pet;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getInventory() {
		return inventory;
	}

	public void setInventory(int inventory) {
		this.inventory = inventory;
	}

	public List<Comment> getComments() {
		return comments;
	}

	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}
}
