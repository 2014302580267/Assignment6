package service;

import java.util.Properties;
import java.util.Random;

import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

/**
 * ����������֤��
 * @author cxq
 *
 */
public class Mail{
	private int identifyCode;//��֤��
	
	public int getIdentifyCode() {
		return identifyCode;
	}

	public void setIdentifyCode(int identifyCode) {
		this.identifyCode = identifyCode;
	}
	
	//�����ʼ�
	public void send(String address) throws MessagingException{
		MailAuthenticator authenticator=new MailAuthenticator("m15827591729@163.com","ntnqhrbkmrzcwuwp");
		
		Properties props = System.getProperties();
		props.put("mail.smtp.auth","true");
	    props.put("mail.smtp.host", "smtp.163.com");
	    props.put("mail.transport.protocol", "stmp");
	    props.put("mail.stmp.user", "m15827591729@163.com");
	    props.put("mail.stmp.password", "ntnqhrbkmrzcwuwp");
	   
	    Session session = Session.getDefaultInstance(props, authenticator);
		
		 final MimeMessage message = new MimeMessage(session);
	        // ���÷�����
	        message.setFrom(new InternetAddress("m15827591729@163.com"));
	        // �����ռ���
	        message.addRecipient(RecipientType.TO, new InternetAddress(address));
	        // ��������
	        message.setSubject("�����̵� ע���û�����������֤");
	        // �����ʼ�����
	        int random=new Random().nextInt(89999)+10000;
	        setIdentifyCode(random);
	        message.setContent("��֤�룺"+String.valueOf(random),"text/html;charset=utf-8");
	        // ����
	        Transport.send(message);
	}
}
