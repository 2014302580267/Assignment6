package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPasswordField;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;

import pojo.Customer;
import dao.CustomersData;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.SQLException;

/**
 * ��½GUI
 * @author cxq
 *
 */
public class LogView extends JFrame {
	private static final long serialVersionUID = 1L;
	
	
	private CustomersData customerData=new CustomersData();
	private Customer customer=new Customer();
	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;
	private RegisterView register=new RegisterView();
	public void vis(boolean b){
		this.setVisible(b);
	}
	/**
	 * ������
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LogView frame = new LogView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LogView() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		textField = new JTextField();
		textField.setBounds(157, 116, 223, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel label = new JLabel("  \u7528\u6237\u540D");
		label.setBounds(62, 119, 54, 15);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("   \u5BC6\u7801");
		label_1.setBounds(62, 161, 54, 15);
		contentPane.add(label_1);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(157, 158, 223, 21);
		contentPane.add(passwordField);
		
		JLabel label_2 = new JLabel("\u7528\u6237\u767B\u5F55");
		label_2.setFont(new Font("����", Font.PLAIN, 28));
		label_2.setForeground(Color.RED);
		label_2.setBounds(165, 39, 121, 44);
		contentPane.add(label_2);
		
		JButton button = new JButton("\u6CE8\u518C\u65B0\u7528\u6237");
		//ע�����û�
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				register.setVisible(true);

			}
		});

		button.setForeground(Color.BLUE);
		button.setBounds(65, 212, 121, 35);
		contentPane.add(button);
		
		JButton button_1 = new JButton("\u767B\u5F55");
		//��½
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String userName=textField.getText();
				char[]c=passwordField.getPassword();
				String password=new String(c);
				try {
					customer=customerData.getCustomer(userName, password);
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if(customer==null){
					Error error=new Error("�û������������");
					error.setVisible(true);
				}else{
					Homepage homepage=new Homepage(customer);
					homepage.setVisible(true);
					vis(false);
				}
			}
		});
		button_1.setForeground(Color.BLUE);
		button_1.setBounds(265, 212, 131, 35);
		contentPane.add(button_1);
	}
}
