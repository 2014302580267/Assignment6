package view;

import java.awt.BorderLayout;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Font;
import java.sql.SQLException;

import javax.swing.JButton;

import dao.CustomersData;
import pojo.Customer;
import service.OneGood;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * ��Ʒϸ��GUI
 * @author cxq
 *
 */
public class Brief extends JFrame {

	private static final long serialVersionUID = 1L;
	
	
	private JPanel contentPane;
	private OneGood oneGood;
	private Customer customer;

	//ˢ��ҳ��
	public void updata() throws ClassNotFoundException, SQLException{
		Customer c=this.customer;
		OneGood oneGood=this.oneGood;
		this.setVisible(false);
		Brief b=new Brief(oneGood,c);
		b.setVisible(true);
	}

	/**
	 * Create the frame
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public Brief(OneGood oneGood,Customer customer) throws ClassNotFoundException, SQLException {
		CartView cartView=new CartView(customer);
		
		this.customer=customer;
		this.oneGood=oneGood;
		
		setDefaultCloseOperation(1);
		setBounds(100, 100, 450, 370);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u5546\u54C1\u8BE6\u60C5");
		label.setFont(new Font("����", Font.PLAIN, 25));
		label.setForeground(Color.RED);
		label.setBounds(30, 10, 110, 48);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u7528\u6237\u540D");
		label_1.setBounds(181, 31, 54, 15);
		contentPane.add(label_1);
		
		JLabel lblNewLabel = new JLabel(customer.getName());
		lblNewLabel.setBounds(245, 31, 54, 15);
		contentPane.add(lblNewLabel);
		
		JButton button = new JButton("\u8D2D\u7269\u8F66");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cartView.setVisible(true);//�򿪹��ﳵ
			}
		});
		button.setForeground(Color.BLUE);
		button.setBounds(339, 27, 93, 23);
		contentPane.add(button);
		
		JLabel lblNewLabel_1 = new JLabel();
		lblNewLabel_1.setIcon(new ImageIcon("images\\"+oneGood.getPet().getType()+".jpg"));//����ͼƬ
		lblNewLabel_1.setBounds(30, 79, 160, 162);
		contentPane.add(lblNewLabel_1,BorderLayout.CENTER);
		
		JLabel lblNewLabel_2 = new JLabel("\u7C7B\u522B\uFF1A");
		lblNewLabel_2.setBounds(219, 79, 54, 15);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\u559D\uFF1A");
		lblNewLabel_3.setBounds(219, 226, 54, 15);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("\u540D\u5B57\uFF1A");
		lblNewLabel_4.setBounds(219, 114, 54, 15);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("\u5E74\u9F84\uFF1A");
		lblNewLabel_5.setBounds(219, 153, 54, 15);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("\u5403\uFF1A");
		lblNewLabel_6.setBounds(219, 189, 54, 15);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("\u4F4F\uFF1A");
		lblNewLabel_7.setBounds(219, 259, 54, 15);
		contentPane.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("\u7231\u597D\uFF1A");
		lblNewLabel_8.setBounds(219, 295, 54, 15);
		contentPane.add(lblNewLabel_8);
		
		JLabel lblType = new JLabel(oneGood.getPet().getType());
		lblType.setBounds(264, 79, 168, 15);
		contentPane.add(lblType);
		
		JLabel lblName = new JLabel(oneGood.getPet().getName());
		lblName.setBounds(264, 114, 168, 15);
		contentPane.add(lblName);
		
		JLabel lblAge = new JLabel(oneGood.getPet().getAge());
		lblAge.setBounds(264, 153, 168, 15);
		contentPane.add(lblAge);
		
		JLabel lblEat = new JLabel(oneGood.getPet().getEat());
		lblEat.setBounds(264, 189, 168, 15);
		contentPane.add(lblEat);
		
		JLabel lblDrink = new JLabel(oneGood.getPet().getDrink());
		lblDrink.setBounds(264, 226, 168, 15);
		contentPane.add(lblDrink);
		
		JLabel lblLive = new JLabel(oneGood.getPet().getLive());
		lblLive.setBounds(264, 259, 168, 15);
		contentPane.add(lblLive);
		
		StringBuilder bt=new StringBuilder();
		for(String s:oneGood.getPet().getHobby()){
			bt.append(s);
			bt.append(";");
		}
		JLabel lblHobby = new JLabel(bt.toString());
		lblHobby.setBounds(264, 295, 168, 15);
		contentPane.add(lblHobby);
		
		JButton btnNewButton = new JButton("\u52A0\u5165\u8D2D\u7269\u7BB1");
		//���빺�ﳵ
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CustomersData customersData=new CustomersData();
				customersData.insertGood(customer, oneGood.getId());
				customer.insertGood(oneGood.getId());
				try {
					updata();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setForeground(Color.BLUE);
		btnNewButton.setBounds(30, 291, 160, 23);
		contentPane.add(btnNewButton);
		
		JButton button_1 = new JButton("\u67E5\u770B\u8BC4\u8BBA");
		//�鿴����
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CommentsView commentsView;
				try {
					commentsView = new CommentsView(customer,oneGood);
					commentsView.setVisible(true);
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		button_1.setForeground(Color.BLUE);
		button_1.setBounds(30, 255, 160, 23);
		contentPane.add(button_1);
	}
}
