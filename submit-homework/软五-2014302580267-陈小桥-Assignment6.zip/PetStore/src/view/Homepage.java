package view;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import pojo.Customer;
import service.OneGood;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

import java.awt.Color;

import javax.swing.SwingConstants;

import java.awt.Font;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.SQLException;

/**
 * ��ҳ
 * @author cxq
 *
 */
public class Homepage extends JFrame {

	private static final long serialVersionUID = 1L;
	
	
	private JPanel contentPane;
	private Customer customer;

	/**
	 * Create the frame.
	 * 
	 */
	public Homepage(Customer customer){
		this.customer=customer;
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setBounds(100, 100, 1200, 672);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		
		JPanel panel_5 = new JPanel();

		contentPane.add(panel);
		
		panel_5.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u5BA0\u7269\u5546\u5E97\u6B22\u8FCE\u60A8\uFF01");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 25));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setBounds(67, 10, 225, 39);
		contentPane.add(lblNewLabel);
		
		JLabel label = new JLabel("\u7528\u6237\u540D\uFF1A");
		label.setBounds(407, 26, 54, 15);
		contentPane.add(label);
		
		
		JLabel lblNewLabel_1 = new JLabel(customer.getName());
		lblNewLabel_1.setBounds(477, 26, 54, 15);
		contentPane.add(lblNewLabel_1);
		
		JLabel label_1 = new JLabel("\u6211\u7684\u8D2D\u7269\u7BB1\uFF1A");
		label_1.setBounds(612, 26, 94, 15);
		contentPane.add(label_1);
		
		JButton button = new JButton("\u8D2D\u7269\u7BB1");
		button.setForeground(Color.BLUE);
		button.setBounds(713, 22, 93, 23);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					CartView cartView=new CartView(customer);
					cartView.setVisible(true);
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		contentPane.add(button);
		
		for(int i=1;i<7;i++){
				try {
					GoodsPanel panel1=new GoodsPanel(198*(i-1),100,i);
					this.add(panel1);
					panel1.setVisible(true);
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
		}
		
		for(int i=7;i<13;i++){
			try {
				GoodsPanel panel1=new GoodsPanel(198*(i-7),385,i);//�������п���������
				this.add(panel1);
				panel1.setVisible(true);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
	}
		
		contentPane.setLayout(null);
	}
	
	/**
	 * ��Ʒ���
	 * @author cxq
	 *
	 */
	public class GoodsPanel extends JPanel{
		private static final long serialVersionUID = 1L;
		
		//�������ID����
		public GoodsPanel(int x,int y,int id) throws ClassNotFoundException, SQLException{
			setBounds(x,y,188,273);
			setVisible(true);
			
			OneGood good=new OneGood(id);
			
			
			JLabel label = new JLabel("");
			label.setBounds(0, 0, 188, 183);
			label.setIcon(new ImageIcon("images/"+good.getPet().getType()+".jpg"));
			//System.out.println("/images/"+good.getPet().getType()+".jpg");
			add(label,BorderLayout.CENTER);
			
			
			JLabel label_1 = new JLabel("  One "+good.getPet().getType()+" : "+good.getPet().getName()+"   ");
			label_1.setBounds(x, y+193, 94, 15);
			add(label_1);
			
			JButton button = new JButton("�鿴����");
			button.setForeground(Color.BLUE);
			button.setBounds(713, 22, 93, 23);
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Brief brief;
					try {
						brief = new Brief(good,customer);
						brief.setVisible(true);
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				}
			});
			add(button);
		}
	}//end GoodsPanel

	public void setCustomer(Customer customer) {
		this.customer=customer;
		
	}

}
