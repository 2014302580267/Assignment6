package view;

import java.awt.BorderLayout;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import pojo.Customer;
import service.OneGood;

import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Font;

import javax.swing.SwingConstants;
import javax.swing.JButton;

import dao.CustomersData;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * 购物车GUI
 * @author cxq
 *
 */
public class CartView extends JFrame {

	private static final long serialVersionUID = 1L;
	
	
	private JPanel contentPane;
	private float sum=0;
	
	private CustomersData customersData=new CustomersData();
	private Customer customer;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public CartView(Customer customer) throws ClassNotFoundException, SQLException {
		this.customer=customer;
		
		setDefaultCloseOperation(1);
		setBounds(100, 100, 570, 464);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u8D2D\u7269\u8F66");
		label.setFont(new Font("宋体", Font.PLAIN, 24));
		label.setForeground(Color.RED);
		label.setBounds(10, 10, 84, 41);
		contentPane.add(label);
		
		
		JLabel label1 = new JLabel(String.valueOf(customer.getAccount()));
		label1.setFont(new Font("宋体", Font.PLAIN, 24));
		label1.setForeground(Color.RED);
		label1.setBounds(290, 10, 84, 41);
		contentPane.add(label1);
		
		JLabel label2 = new JLabel("余额：");
		label2.setFont(new Font("宋体", Font.PLAIN, 24));
		label2.setForeground(Color.RED);
		label2.setBounds(200, 10, 84, 41);
		contentPane.add(label2);
		
		
		List<Integer> l=new ArrayList<Integer>();
		l=customer.getGoodsList();
		if(l.isEmpty());
		else{
			for(int i=0;i<l.size();i++){
				GoodPanel panel=new GoodPanel(10+i*190,l.get(i));
				sum=sum+panel.getOneGood().getPrice();
			}
		}
		
		JButton btnNewButton = new JButton("\u7ED3\u7B97\u6E05\u5355");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OK ok=new OK(customer,sum);
				ok.setVisible(true);
				
			}
		});
		btnNewButton.setForeground(Color.BLUE);
		btnNewButton.setBounds(420, 375, 132, 48);
		contentPane.add(btnNewButton);
		
		
		JLabel lblNewLabel = new JLabel(String.valueOf(sum));
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setFont(new Font("宋体", Font.PLAIN, 24));
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setBounds(211, 375, 169, 48);
		contentPane.add(lblNewLabel);
		
		
		contentPane.setVisible(true);
	}
		
	//每个商品的面板类
	public class GoodPanel extends JPanel{
		
		private static final long serialVersionUID = 1L;
		

		private OneGood good;
	
		public OneGood getOneGood() {
			return good;
		}

		
		public GoodPanel(int x,int gid) throws ClassNotFoundException, SQLException{
			this.good=new OneGood(gid);
			
			setBounds(x, 61, 170, 303);
			contentPane.add(this);
			setLayout(null);
			setVisible(true);
			
			JLabel lblImage = new JLabel("image");
			lblImage.setBounds(0, 0, 170, 167);
			lblImage.setIcon(new ImageIcon("/images/"+good.getPet().getType()+".jpg"));
			add(lblImage,BorderLayout.CENTER);
			
			JLabel lblType = new JLabel(good.getPet().getType());
			lblType.setBounds(10, 173, 54, 15);
			add(lblType);
			
			JLabel lblName = new JLabel(good.getPet().getName());
			lblName.setBounds(88, 173, 54, 15);
			add(lblName);
			
			JLabel lblPrice = new JLabel("¥"+String.valueOf(good.getPrice()));
			lblPrice.setHorizontalAlignment(SwingConstants.CENTER);
			lblPrice.setFont(new Font("宋体", Font.PLAIN, 24));
			lblPrice.setForeground(Color.RED);
			lblPrice.setBounds(38, 198, 93, 29);
			add(lblPrice);
			
			JButton button = new JButton("\u5220\u9664\u5546\u54C1");//delete
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					customersData.deleteGood(customer, good.getId());
					customer.deleteGood(good.getId());
					try {
						updata();
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});
			button.setForeground(Color.BLUE);
			button.setBounds(38, 237, 93, 23);
			add(button);
			
			JButton button_1 = new JButton("\u8D2D\u4E70");//get
			button_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					OK ok=new OK(customer,good.getPrice());
					ok.setVisible(true);
				}
			});
			button_1.setForeground(Color.BLUE);
			button_1.setBounds(38, 266, 93, 23);
			add(button_1);
		}
	}
	
	//刷新页面
	public void updata() throws ClassNotFoundException, SQLException{
		Customer c=this.customer;
		this.setVisible(false);
		CartView cart=new CartView(c);
		cart.setVisible(true);
	}
	
	
	//内部类确认支付GUI
	public class OK extends JFrame {

		private static final long serialVersionUID = 1L;
		
		private JPanel contentPane;
		private CustomersData customersData=new CustomersData();
		/**
		 * Create the frame.
		 */
		public OK(Customer customer,float price) {
			setDefaultCloseOperation(1);
			setBounds(100, 100, 450, 300);
			contentPane = new JPanel();
			contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
			setContentPane(contentPane);
			contentPane.setLayout(null);
			
			JLabel lblNewLabel = new JLabel("确认支付 ¥"+String.valueOf(price)+"?");
			lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel.setBounds(0, 0, 442, 186);
			contentPane.add(lblNewLabel);
			
			JButton button = new JButton("\u786E\u8BA4");
			//确认支付
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(customer.getAccount()-price<0){
						setVisible(false);
						Error error=new Error("金额不足！");
						error.setVisible(true);
					}else{
					try {
						customersData.changeCustomerAttri(customer.getId(), "account", String.valueOf(customer.getAccount()-price));
						customer.setAccount(customer.getAccount()-price);
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					try {
						updata();
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					setVisible(false);
				}
				}
			});
			button.setForeground(Color.BLUE);
			button.setBounds(173, 217, 93, 23);
			contentPane.add(button);
		}

	}
	}


