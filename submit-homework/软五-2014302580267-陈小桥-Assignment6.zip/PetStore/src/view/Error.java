package view;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * ����GUI
 * @author cxq
 *
 */
public class Error extends JFrame {
	private static final long serialVersionUID = 1L;
	
	
	private JPanel contentPane;

	/**
	 * Create the frame.
	 */
	public Error(String s) {
		setDefaultCloseOperation(1);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel(s);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(31, 35, 381, 145);
		contentPane.add(lblNewLabel);
		
		JButton button = new JButton("\u786E\u5B9A");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();//�п���������
			}
		});
		button.setForeground(Color.BLUE);
		button.setBounds(176, 212, 93, 23);
		contentPane.add(button);
	}

}
