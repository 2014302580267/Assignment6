package view;

import service.Mail;

import javax.mail.MessagingException;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JButton;

import pojo.Customer;
import dao.CustomersData;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ע��GUI
 * @author cxq
 *
 */
public class RegisterView extends JFrame {

	private static final long serialVersionUID = 1L;
	
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	
	private int identifyCode=0;
	
	public int getIdentifyCode() {
		return identifyCode;
	}

	/**
	 * Create the frame.
	 */
	public RegisterView() {
		setDefaultCloseOperation(1);
		setBounds(100, 100, 450, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u6CE8\u518C\u7528\u6237");
		label.setFont(new Font("����", Font.PLAIN, 28));
		label.setForeground(Color.RED);
		label.setBounds(165, 10, 120, 51);
		contentPane.add(label);
		
		JLabel lblNewLabel = new JLabel("\u5BC6\u7801");
		lblNewLabel.setBounds(66, 125, 54, 15);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u90AE\u7BB1");
		lblNewLabel_1.setBounds(66, 172, 37, 15);
		contentPane.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(142, 122, 258, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(142, 169, 258, 21);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel label_1 = new JLabel("\u7528\u6237\u540D");
		label_1.setBounds(66, 78, 54, 15);
		contentPane.add(label_1);
		
		textField_2 = new JTextField();
		textField_2.setBounds(142, 75, 258, 21);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel label_2 = new JLabel("�û�����");
		label_2.setBounds(66, 219, 54, 15);
		contentPane.add(label_2);
		
		textField_3 = new JTextField();
		textField_3.setBounds(142, 216, 258, 21);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		JButton button = new JButton("��ȡ��֤��");
		//��ȡ��֤��
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CustomersData customersData=new CustomersData();
				
				try {
					//�����û����Ƿ����
					if(customersData.ExistCustomer(textField_2.getText())){
						Error error=new Error("�û����Ѵ��ڣ�");
						error.setVisible(true);
					}
					else{
						//���������ʽ�Ƿ���ȷ
						String mail=textField_1.getText();
						Pattern pattern = Pattern.compile("^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$");
						Matcher m=pattern.matcher(mail);
						if(!m.matches()){
							Error error=new Error("��������ȷ��ʽ�������ַ");
							error.setVisible(true);
						}else{
						
							sendMessage(mail);
						}
					}
					} catch (InstantiationException | IllegalAccessException | MessagingException | IOException | InterruptedException | SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});
		button.setForeground(Color.BLUE);
		button.setBounds(131, 260, 174, 41);
		contentPane.add(button);
		
		JLabel label_3 = new JLabel("��֤�룺");
		label_3.setBounds(66, 327, 54, 15);
		contentPane.add(label_3);
		
		textField_4 = new JTextField();
		textField_4.setBounds(142, 324, 258, 21);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		JButton button2 = new JButton("ע��");
		//��֤�ɹ�����ʽע��
		button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CustomersData customersData=new CustomersData();

					String mail=textField_1.getText();
					Customer customer;
					try {
						if(textField_4.getText().equals(String.valueOf(identifyCode))){
							customer = new Customer(customersData.maxId()+1);
							customer.setUserName(textField_2.getText());
							customer.setPassword(textField.getText());
						
							String user=textField_3.getText();
							customer.setName(user);
							customer.setEmail(mail);
							customersData.insertCustomer(customer);
							setVisible(false);
						}else{
							Error error=new Error("��֤�벻��ȷ!");
							error.setVisible(true);
						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
			}
		});
		button2.setForeground(Color.BLUE);
		button2.setBounds(131, 368, 174, 41);
		contentPane.add(button2);
	}
	
	//����������֤��
	public void sendMessage(String address) throws InstantiationException, IllegalAccessException, MessagingException, IOException, InterruptedException{
		
		Mail mail=new Mail();
		mail.send(address);
		identifyCode=mail.getIdentifyCode();
	}

}
