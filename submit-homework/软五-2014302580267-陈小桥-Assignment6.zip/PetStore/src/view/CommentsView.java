package view;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Font;
import java.sql.SQLException;
import java.util.List;

import javax.swing.SwingConstants;

import pojo.Comment;
import pojo.Customer;
import service.OneGood;
import dao.CommentsData;
import dao.CustomersData;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.IOException;

/**
 * �鿴����GUI
 * @author cxq
 *
 */
public class CommentsView extends JFrame {

	private static final long serialVersionUID = 1L;
	
	
	private JPanel contentPane;
	private CommentsData commentsData=new CommentsData();
	private CustomersData customersData=new CustomersData();
	private Customer customer;
	private OneGood oneGood;

	/**
	 * Launch the application.
	 */
	
	/**
	 * Create the frame.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public CommentsView(Customer c,OneGood oneGood) throws ClassNotFoundException, SQLException {
		
		this.customer=c;
		this.oneGood=oneGood;
		
		//��ȡ���ж������Ʒ������
		List<Comment> comments=commentsData.getCommentsByGid(oneGood.getId());
		Comment[] com = new Comment[24];
		for(int i=0;i<comments.size();i++){
			com[i]=comments.get(i);
		}
		
		
		setDefaultCloseOperation(1);
		setBounds(100, 100, 450, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Customer customer=customersData.getCustomer(com[0].getPid());
		
		JLabel label = new JLabel("\u8BC4\u8BBA");
		label.setFont(new Font("����", Font.PLAIN, 24));
		label.setForeground(Color.RED);
		label.setBounds(10, 10, 68, 33);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u8BC4\u8BBA\u4EBA\uFF1A");
		label_1.setBounds(10, 53, 54, 15);
		contentPane.add(label_1);
		
		JLabel lblPerson = new JLabel(customer.getName());
		lblPerson.setBounds(74, 53, 54, 15);
		contentPane.add(lblPerson);
		
		JLabel label_2 = new JLabel("\u6EE1\u610F\u5EA6\uFF1A");
		label_2.setBounds(166, 53, 54, 15);
		contentPane.add(label_2);
		
		JLabel lblStar = new JLabel(String.valueOf(com[0].getStar())+"��");
		lblStar.setBounds(230, 53, 54, 15);
		contentPane.add(lblStar);
		
		JLabel label_3 = new JLabel("\u5BA0\u7269\uFF1A");
		label_3.setBounds(294, 53, 54, 15);
		contentPane.add(label_3);
		
		JLabel lblPet = new JLabel(oneGood.getPet().getName());
		lblPet.setBounds(352, 53, 54, 15);
		contentPane.add(lblPet);
		
		JLabel lblContent = new JLabel(com[0].getContent());
		lblContent.setVerticalAlignment(SwingConstants.TOP);
		lblContent.setBounds(10, 88, 422, 22);
		contentPane.add(lblContent);
		
		Customer customer2=customersData.getCustomer(com[1].getPid());
		
		JLabel label_4 = new JLabel("\u8BC4\u8BBA\u4EBA\uFF1A");
		label_4.setBounds(10, 151, 54, 15);
		contentPane.add(label_4);
		
		JLabel label_5 = new JLabel(customer2.getName());
		label_5.setBounds(74, 151, 54, 15);
		contentPane.add(label_5);
		
		JLabel label_6 = new JLabel("\u6EE1\u610F\u5EA6\uFF1A");
		label_6.setBounds(166, 151, 54, 15);
		contentPane.add(label_6);
		
		JLabel label_7 = new JLabel(String.valueOf(com[1].getStar())+"��");
		label_7.setBounds(230, 151, 54, 15);
		contentPane.add(label_7);
		
		JLabel label_8 = new JLabel("\u5BA0\u7269\uFF1A");
		label_8.setBounds(294, 151, 54, 15);
		contentPane.add(label_8);
		
		JLabel label_9 = new JLabel(oneGood.getPet().getName());
		label_9.setBounds(352, 151, 54, 15);
		contentPane.add(label_9);
		
		JLabel label_10 = new JLabel(com[1].getContent());
		label_10.setVerticalAlignment(SwingConstants.TOP);
		label_10.setBounds(10, 189, 422, 22);
		contentPane.add(label_10);
		
		
		
		if(comments.size()>2){
		Customer customer3=customersData.getCustomer(com[2].getPid());
		
		JLabel label_11 = new JLabel("\u8BC4\u8BBA\u4EBA\uFF1A");
		label_11.setBounds(10, 249, 54, 15);
		contentPane.add(label_11);
		
		JLabel lblPerson3 = new JLabel(customer3.getName());
		lblPerson3.setBounds(74, 249, 54, 15);
		contentPane.add(lblPerson3);
		
		JLabel label_12 = new JLabel("\u6EE1\u610F\u5EA6\uFF1A");
		label_12.setBounds(166, 249, 54, 15);
		contentPane.add(label_12);
		
		JLabel lblStar3 = new JLabel(String.valueOf(com[2].getStar())+"��");
		lblStar3.setBounds(230, 249, 54, 15);
		contentPane.add(lblStar3);
		
		JLabel label_13 = new JLabel("\u5BA0\u7269\uFF1A");
		label_13.setBounds(294, 249, 54, 15);
		contentPane.add(label_13);
		
		JLabel lblPet3 = new JLabel(oneGood.getPet().getName());
		lblPet3.setBounds(352, 249, 54, 15);
		contentPane.add(lblPet3);
		
		JLabel lblContent3 = new JLabel(com[2].getContent());
		lblContent3.setVerticalAlignment(SwingConstants.TOP);
		lblContent3.setBounds(10, 287, 422, 22);
		contentPane.add(lblContent3);
		}
		
		
		JButton btnNewButton = new JButton("\u6DFB\u52A0\u8BC4\u8BBA");	
		//��������
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					AddComment addComment = new AddComment(c,oneGood);
					addComment.setVisible(true);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton.setBounds(315, 10, 93, 23);
		contentPane.add(btnNewButton);
		
		
		
	}
	
	//ˢ��ҳ��
	public void updata() throws ClassNotFoundException, SQLException{
		Customer customer=this.customer;
		OneGood oneGood=this.oneGood;
		this.setVisible(false);
		CommentsView c=new CommentsView(customer,oneGood);
		c.setVisible(true);
	}
	
/**
 * �ڲ�����������
 * @author cxq
 *
 */
public class AddComment extends JFrame{

	private static final long serialVersionUID = 1L;
	
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 * @throws IOException 
	 */
	public AddComment(Customer customer,OneGood oneGood) throws IOException {
		setDefaultCloseOperation(1);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u5BA0\u7269\uFF1A");
		lblNewLabel.setBounds(36, 10, 54, 15);
		contentPane.add(lblNewLabel);
		
		JLabel lblPet = new JLabel(oneGood.getPet().getName());
		lblPet.setBounds(78, 10, 54, 15);
		contentPane.add(lblPet);
		
		JComboBox<String> comboBox = new JComboBox<String>();
		comboBox.setModel(new DefaultComboBoxModel<String>(new String[] {"0\u661F", "1\u661F", "2\u661F", "3\u661F", "4\u661F", "5\u661F"}));
		comboBox.setSelectedIndex(5);
		comboBox.setMaximumRowCount(6);
		comboBox.setBounds(305, 7, 55, 21);
		contentPane.add(comboBox);
		
		JLabel label = new JLabel("\u6EE1\u610F\u5EA6\uFF1A");
		label.setBounds(241, 10, 54, 15);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u8BC4\u8BBA\u5185\u5BB9\uFF1A");
		label_1.setBounds(38, 54, 71, 15);
		contentPane.add(label_1);
		
		JEditorPane editorPane = new JEditorPane();
		editorPane.setBounds(38, 91, 377, 110);
		contentPane.add(editorPane);
		
		JButton button = new JButton("\u786E\u5B9A");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int star=comboBox.getSelectedIndex();
				String content=editorPane.getText();
				
				Comment comment=new Comment();
				comment.setPid(customer.getId());
				comment.setGid(oneGood.getId());
				comment.setStar(star);
				comment.setContent(content);
				
				CommentsData commentsData=new CommentsData();
				try {
					commentsData.insertComment(comment);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					updata();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				setVisible(false);
			}
		});
		button.setForeground(Color.BLUE);
		button.setBounds(322, 226, 93, 23);
		contentPane.add(button);
	}
}


}

