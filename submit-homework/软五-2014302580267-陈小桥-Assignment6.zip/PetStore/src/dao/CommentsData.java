package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import pojo.Comment;
/**
 * �����ݿ�������۵Ľ���
 * @author cxq
 *
 */

public class CommentsData {
	private Loader loader=new Loader();
	private Statement st=loader.getStatement();
	private ResultSet r;
	private List<Comment> idComments=new ArrayList<Comment>();
	private List<Comment> gidComments=new ArrayList<Comment>();
	private List<Comment> pidComments=new ArrayList<Comment>();
	
	//ͨ��ID��ȡ����
	public List<Comment> getCommentsById(int id) throws ClassNotFoundException, SQLException{
		r=st.executeQuery("select * from 2014302580267_Comments where id="+id+";");
		while(r.next()){
			Comment c=new Comment();
			c.setId(r.getInt("id"));
			c.setPid(r.getInt("pid"));
			c.setGid(r.getInt("gid"));
			c.setStar(r.getInt("star"));
			c.setContent(r.getString("content"));
			
			
			idComments.add(c);
		}
		return idComments;
	}
	
	//ͨ��GID��ȡ����
	public List<Comment> getCommentsByGid(int gid) throws ClassNotFoundException, SQLException{
		r=st.executeQuery("select * from 2014302580267_Comments where gid="+gid+";");
		while(r.next()){
			Comment c=new Comment();
			c.setId(r.getInt("id"));
			c.setPid(r.getInt("pid"));
			c.setGid(r.getInt("gid"));
			c.setStar(r.getInt("star"));
			c.setContent(r.getString("content"));
			
			
			gidComments.add(c);
		}
		return gidComments;
	}
	
	//ͨ��PID��ȡ����
	public List<Comment> getCommentsByPid(int pid) throws ClassNotFoundException, SQLException{
		r=st.executeQuery("select * from 2014302580267_Comments where pid="+pid+";");
		while(r.next()){
			Comment c=new Comment();
			c.setId(r.getInt("id"));
			c.setPid(r.getInt("pid"));
			c.setGid(r.getInt("gid"));
			c.setStar(r.getInt("star"));
			c.setContent(r.getString("content"));
			
			
			pidComments.add(c);
		}
		return pidComments;
	}
	
	
	//ɾĳ����Ʒ
	public void deleteComment(int id) throws SQLException{
		st.execute("delete from 2014302580267_Comments where id="+String.valueOf(id)+";");
	}
	//��ĳ����Ʒ
	public void insertComment(Comment c) throws SQLException{
		st.execute("insert into 2014302580267_Comments (pid,gid,star,content) values('"+String.valueOf(c.getPid())+"','"+String.valueOf(c.getGid())+"','"+String.valueOf(c.getStar())+"','"+c.getContent()+"');");
	}
	//��ĳ����Ʒĳ������
	public void changeCommentAttri(int id,String column,String changeTo) throws SQLException{
		st.execute("update 2014302580267_Comments set "+column+"='"+changeTo+"' where id="+String.valueOf(id)+";");
	}
}
