package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import pojo.Customer;

/**
 * �����ݿ�����û��Ľ���
 * @author cxq
 *
 */
public class CustomersData {
	private Loader loader=new Loader();
	private Statement st=loader.getStatement();
	private ResultSet r;
	
	//��ȡ���ID
	public int maxId() throws SQLException{
		r=st.executeQuery("select * from 2014302580267_Customers;");
		int max=0;
		while(r.next()){
			if(r.getInt("id")>max)
				max=r.getInt("id");
		}
		return max;
	}
	
	//ͨ��ID��ȡ�û�
	public Customer getCustomer(int id) throws SQLException{
		r=st.executeQuery("select * from 2014302580267_Customers where id="+String.valueOf(id));
		Customer c=new Customer();
		while(r.next()){
			c.setId(r.getInt("id"));
			c.setIid(r.getString("iid"));//��Сд!!!!!!!
			c.setAccount(r.getFloat("account"));
			c.setName(r.getString("name"));
			c.setSex(r.getString("sex"));
			c.setPhoneNumber(r.getInt("phoneNumber"));
			c.setEmail(r.getString("email"));
			
			List<Integer> l=new ArrayList<Integer>();
			String s=r.getString("goodsList");
			if(s.equals(""));
			else if(!s.contains("+"))
				l.add(Integer.parseInt(s));
			else{
				for(String str:s.split("+")){
					l.add(Integer.parseInt(str));
				}
			}
			c.setGoodsList(l);
		}
		return c;
	}
	
	//ĳ���û����Ƿ����
	public boolean ExistCustomer(String userName) throws SQLException{
		r=st.executeQuery("select * from 2014302580267_Customers;");
		while(r.next()){
			if(r.getString("userName").equals(userName)){
				return true;
			}
		}
			return false;
			
	}
	
	//ͨ���û��������ȡ�û�
	public Customer getCustomer(String userName,String password) throws ClassNotFoundException, SQLException{
		r=st.executeQuery("select * from 2014302580267_Customers;");

		while(r.next()){
			if(r.getString("userName").equals(userName)&&r.getString("password").equals(password)){

				Customer c=new Customer();
				c.setId(r.getInt("id"));
				c.setIid(r.getString("iid"));//��Сд!!!!!!!
				c.setAccount(r.getFloat("account"));
				c.setName(r.getString("name"));
				c.setSex(r.getString("sex"));
				c.setPhoneNumber(r.getInt("phoneNumber"));
				c.setEmail(r.getString("email"));

				
				List<Integer> l=new ArrayList<Integer>();
				String s=r.getString("goodsList");
				if(s.equals(""));
				else if(!s.contains("+"))
					l.add(Integer.parseInt(s));
				else{
					for(String str:s.split("\\+")){
						l.add(Integer.parseInt(str));
					}
				}

				c.setGoodsList(l);

				return c;
			}
		}
		return null;
	}
	
	
	
	//ɾĳ���û�
	public void deleteCustomer(int id) throws SQLException{
		st.execute("delete from 2014302580267_Customers where id="+String.valueOf(id)+";");
	}
	//��ĳ����Ʒ
	public void insertCustomer(Customer c) throws SQLException{
		st.execute("insert into 2014302580267_Customers (id,userName,password,account,name,email) values("+String.valueOf(c.getId())+",'"+c.getUserName()+"','"+c.getPassword()+"',"+String.valueOf(c.getAccount())+",'"+c.getName()+"','"+c.getEmail()+"');");
	}
	//������Ʒ
	public boolean insertGood(Customer c,int id){
		boolean b=true;
		String s="";
		try {
			r=st.executeQuery("select * from 2014302580267_Customers where id="+String.valueOf(c.getId())+";");
			while(r.next()){
				s=r.getString("goodsList");
				if(s.equals("")){
					s=String.valueOf(id);
				}
				else{
					List<Integer> l=new ArrayList<Integer>();
					l=c.getGoodsList();
					
					for(int i:l)
						if(i==id){
							b=false;break;
						}
					if(b)
						s=s+"+"+String.valueOf(id);
				}
					
			}
			st.execute("update 2014302580267_Customers set goodsList='"+s+"' where id="+String.valueOf(c.getId())+";");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return b;
	}
	
	//�ڹ��ﳵ��ɾ��ĳ����Ʒ
	public void deleteGood(Customer c,int id){
		List<Integer> l=new ArrayList<Integer>();
		l=c.getGoodsList();
		if(l.size()!=0){
			for(int i=0;i<l.size();i++)
				if(l.get(i)==id)
					l.remove(i);
		}
		String s="";
		if(l.size()==0)
			s="";
		else if(l.size()==1)
			s=String.valueOf(l.get(0));
		else{
			s=String.valueOf(l.get(0));
				for(int i=1;i<l.size();i++)
				s=s+"+"+String.valueOf(l.get(i));
		}
		try {
			st.execute("update 2014302580267_Customers set goodsList='"+s+"' where id="+String.valueOf(c.getId())+";");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//��ĳ����Ʒĳ������
	public void changeCustomerAttri(int id,String column,String changeTo) throws SQLException{
		st.execute("update 2014302580267_Customers set "+column+"="+changeTo+" where id="+String.valueOf(id)+";");
	}
}
	

