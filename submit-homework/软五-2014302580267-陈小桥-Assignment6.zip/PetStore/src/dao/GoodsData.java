package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import pojo.Goods;

/**
 * �����ݿ������Ʒ����
 * @author cxq
 *
 */
public class GoodsData {
	private Loader loader=new Loader();
	private Statement st=loader.getStatement();
	private ResultSet r;
	
	//ͨ��ID��ȡ��Ʒ
	public Goods getGoods(int id) throws ClassNotFoundException, SQLException{
		r=st.executeQuery("select * from 2014302580267_Goods where id="+String.valueOf(id)+";");
				Goods g=new Goods();
				while(r.next()){
				g.setId(r.getInt("id"));
				g.setPrice(r.getFloat("price"));
				g.setInventory(r.getInt("inventory"));
				}
				return g;
	}
	
	
	//ɾĳ����Ʒ
	public void deleteGood(int id) throws SQLException{
		st.execute("delete from 2014302580267_Goods where id="+String.valueOf(id)+";");
	}
	//��ĳ����Ʒ
	public void insertGood(Goods g) throws SQLException{
		st.execute("insert into 2014302580267_Goods values('"+String.valueOf(g.getId())+"','"+String.valueOf(g.getPrice())+"','"+String.valueOf(g.getInventory())+"');");
	}
	//��ĳ����Ʒĳ������
	public void changePetAttri(int id,String column,String changeTo) throws SQLException{
		st.execute("update 2014302580267_Goods set "+column+"='"+changeTo+"' where id="+String.valueOf(id)+";");
	}
}
