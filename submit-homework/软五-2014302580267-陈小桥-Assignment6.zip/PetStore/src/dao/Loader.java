package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * �������ݿ�
 * @author cxq
 *
 */
public class Loader {
	private String url="jdbc:mysql://127.0.0.1:3306/PetStore?user=root&password=123456";
	private String user="root";
	private String password="19950707";
	private Statement st;
	
	//����
	public Loader(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection(url, user, password);
			st=conn.createStatement();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public Statement getStatement(){
		return this.st;
	}
}
