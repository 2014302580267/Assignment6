package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Set;
import java.util.TreeSet;

import pojo.Pet;

/**
 * �����ݿ���г��ｻ��
 * @author cxq
 *
 */
public class PetsData {
	private Loader loader=new Loader();
	private Statement st=loader.getStatement();
	private ResultSet r;
	private Set<String> s=new TreeSet<String>();
	
	//ͨ��ID��ȡ����
	public Pet getPet(int id) throws ClassNotFoundException, SQLException{
		r=st.executeQuery("select * from 2014302580267_Pets where id="+String.valueOf(id)+";");
		Pet p=new Pet();
		while(r.next()){
			p.setId(r.getInt("id"));
			p.setType(r.getString("type"));
			p.setName(r.getString("name"));//��Сд!!!!!!!
			p.setAge(r.getString("age"));
			p.setEat(r.getString("eat"));
			p.setDrink(r.getString("drink"));
			p.setLive(r.getString("live"));
			
			String h=r.getString("hobby");
			s.clear();
			int j=0;
			while(j<h.split(" ").length){
				s.add(h.split(" ")[j]);
				j++;
			}
			p.setHobby(s);
		}
			return p;
		
	}
	
	//ɾĳ������
	public void deletePet(int id) throws SQLException{
		st.execute("delete from 2014302580267_Pets where id="+String.valueOf(id)+";");
	}
	//��ĳ������
	public void insertPet(Pet p) throws SQLException{
		StringBuilder bt=new StringBuilder();
		for(String s:p.getHobby()){
			bt.append(s);
			bt.append(";");
		}
		st.execute("insert into 2014302580267_Pets values('"+String.valueOf(p.getId())+"','"+p.getType()+"','"+p.getName()+"','"+p.getAge()+"','"+p.getEat()+"','"+p.getDrink()+"','"+p.getLive()+"','"+bt.toString()+"');");
	}
	//��ĳ������ĳ������
	public void changePetAttri(int id,String column,String changeTo) throws SQLException{
		st.execute("update 2014302580267_Pets set "+column+"='"+changeTo+"' where id="+String.valueOf(id)+";");
	}
}
